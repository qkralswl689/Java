/**
 * 
 */
package sample_project;

// 키워드  ,  사용자 워드
/**
 * @author 82104
 *
 */
public class JavaEx1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// main => 소문자로만 작성 해야한다

		System.out.println("java자바");
	}

}
